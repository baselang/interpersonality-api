import React, { Component } from 'react';
import { Alert, Button } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';
import $ from 'jquery';
import CardElementDemo from './CardElementDemo';

class UserDetails extends Component {
    constructor(){
        super();
        this.state = {
            status: false,
            invoice_url: '',
            portal_session: '',
            iframe: false,
            access_url: ''
        }
    }

    componentWillMount() {

        let portal_session =  localStorage.getItem("portal_session")

        fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/getcustomersite`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
                "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue"
            },
        }).then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(data => {
            localStorage.setItem("portal_session", data.body.portal_session)
            if(data.status === 200) {
                this.setState({
                    portal_session: data.body.portal_session
                })
                window.Chargebee.init({
                    site: data.body.site
                })
            }
        })

        fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/gethostedpages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
                "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue"
            },
        }).then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(data => {
            if(data.status === 200) {
                this.setState({
                    hosted_page: data.body.hosted_page,
                    access_url: data.body.payment_method_hosted_page.url
                })
                window.Chargebee.init({
                    site: data.body.site
                })
            }
        })

        var urlParams = new URLSearchParams(window.location.search)
        const token = urlParams.get('token');

        if(token !== null) {

            fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/addpaypal`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Credentials": true,
                    "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue",
                    "token_id": token
                },
            }).then(response => response.json().then(data => ({ status: response.status, body: data })))
            .then(data => {
                if(data.status === 200) {
                    this.handleEditpayment();
                }
            })
        }
    }

    handleChange = (e) => {

        this.setState({[e.target.name]: e.target.value})
    }

    handleEditpayment = () => {

        var portal_session = this.state.portal_session

        $(document).ready(function () {

            var cbInstance = window.Chargebee.getInstance();
            cbInstance.setPortalSession(function(){
                return new Promise(function(resolve, reject){
                    resolve(portal_session);
                });
            })
            var cbPortal = cbInstance.createChargebeePortal();
            cbPortal.openSection({
                sectionType: window.Chargebee.getPortalSections().PAYMENT_SOURCES
            });

        }) 
    }

    handleCheckout = () => {

        let hosted_page = this.state.hosted_page;

        $(document).ready(function () {

            var cbInstance = window.Chargebee.getInstance();

            cbInstance.openCheckout({
                hostedPage: function() {
                    return new Promise(function(resolve, reject){
                        resolve(hosted_page);
                    });
                }
            })     
        }) 
    }
    
    handleMakepayment = (event) => {
        event.preventDefault();

        fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/paysubscription`, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
                "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue"
            },
        }).then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(data => {
            if(data.status === 200) {
                this.setState({
                    invoice_url: data.body.invoice_url,
                    status: true
                })
                
            }
        })
    }

    handlePaypal = (event) => {
        event.preventDefault();


        fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/getpaypalurl`, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
                "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue"
            },
        }).then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(data => {
            if(data.status === 200) {
                window.location.replace(data.body.redirect_url)
            }
        })
    }

    handleIframe = (event) => {
        event.preventDefault();

        this.setState({
            iframe: true
        })
    }

    handleInvoice = () => {
        window.open(this.state.invoice_url)
    }

    render() {
        return (
            <div>
                <h1>Chargebee demo</h1>
                <Button size="lg" variant="primary" type="submit" onClick={this.handleEditpayment}>
                    Payment Method (Popup)
                </Button>{" "}
                <Button size="lg" variant="primary" type="submit" onClick={this.handleIframe}>
                    Payment Method (Iframe)
                </Button>{" "}
                <Button size="lg" variant="primary" type="submit" onClick={this.handlePaypal}>
                   PayPal
                </Button>{" "}
                <br></br>
                <br></br>
                {this.state.iframe && 
                    <iframe style={{ width: "350px", height: "500px", overflow: "hidden"}} frameborder="0"  scrolling="no"  src={`${this.state.access_url}`}></iframe>
                }
                <br></br>
                <br></br>
                <Button size="lg" variant="primary" type="submit" onClick={this.handleMakepayment}>
                    Pay $500 & Generate Invoice
                </Button>
                <br></br>
                <br></br>
                { this.state.status && 
                    <Alert show={this.state.status} variant="success">
                        <Alert.Heading>User payment is Successfull</Alert.Heading>
                    </Alert>
                }

                { this.state.status && 

                <Button size="lg" variant="primary" type="submit" onClick={this.handleInvoice}>
                    View Invoice
                </Button>

                }               
                <br></br>
                <br></br>
                <Button size="lg" variant="primary" type="submit" onClick={this.handleCheckout}>
                   Hosted Pages Checkout
                </Button>
                <CardElementDemo />
            </div>
        )
    }
}

export default withRouter(UserDetails);