
import React, { useState, useEffect } from 'react';
import {
  CardElement,
  Elements,
  RecurlyProvider,
  useRecurly
} from '@recurly/react-recurly';

const handleBlur = () => console.log('[blur]');
const handleChange = change => console.log('[change]', change);
const handleFocus = () => console.log('[focus]');
const handleReady = () => console.log('[ready]');


function CardElementDemo (props) {
  const [fontSize] = useState('18');

  return (
    <div>
      <h1>React-recurly demo</h1>
      <h2>Step 1. Please provide the card details and click on Add Payment Method... button</h2>
      <br/>
      <h2>Step 2. You can check the generated invoice by clicking on Download Invoice button after successful payment</h2>
      <br/>
      <h2>Step 3. You can also add PayPal account for payment by clicking on Subscribe with PayPal... button</h2>
      <br/>
      <h2>Step 4. You can also add PayPal account and make payment by clicking on Subscribe with PayPal button</h2>
      <br/>
      <h2>Step 5. You can directly make payment using existing payment methoid by clicking on Pay $500 button</h2>
      <br/>
      <h2>Card Element</h2>
      <div className="DemoSection">
        <RecurlyProvider publicKey="dev-Cyx80WKsy3H1qd748r1wzi">
          <Elements>
            <CardForm fontSize={`${fontSize}px`} />
          </Elements>
        </RecurlyProvider>
      </div>
    </div>
  );
}

export default CardElementDemo;

function CardForm (props) {
  const { fontSize } = props;
  const recurly = useRecurly();
  // recurly.PayPal();
  let form = React.createRef();
  const [success, setSuccess] = useState('')
  const [pdf, setPdf] = useState('')

  const handleSubmit = event => {
    if (event.preventDefault) event.preventDefault();
    recurly.token(form.current, (err, token) => {
      // if (err) console.log('[error]', err);
      // else console.log('[token]', token);
      fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/createcustomerpurchase`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Credentials": true,
                    "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue",
                    "token_id": token.id
                },
            }).then(response => response.json().then(data => ({ status: response.status, body: data })))
            .then(data => {
              if(data.status === 200) {
                var hex = (data.body.pdf)
                var byteArray = new Uint8Array(hex.length/2);
                  for (var x = 0; x < byteArray.length; x++){
                      byteArray[x] = parseInt(hex.substr(x*2,2), 16);
                  }

                  var blob = new Blob([byteArray], {type: "application/pdf"});
                  var fileURL = URL.createObjectURL(blob);

              setPdf(fileURL)
              setSuccess(data.body.message)
              }
              if(data.status === 500) {
                setSuccess(data.body.message)
              }
            })
    });
  };

  const handlePay = event => {
    if (event.preventDefault) event.preventDefault();
    
      fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/createcustomerpurchase`, {
          method: "POST",
          headers: {
              'Content-Type': 'application/json',
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Credentials": true,
              "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue"
          },
      }).then(response => response.json().then(data => ({ status: response.status, body: data })))
      .then(data => {
        if(data.status === 200) {
          var hex = (data.body.pdf)
          var byteArray = new Uint8Array(hex.length/2);
            for (var x = 0; x < byteArray.length; x++){
                byteArray[x] = parseInt(hex.substr(x*2,2), 16);
            }

            var blob = new Blob([byteArray], {type: "application/pdf"});
            var fileURL = URL.createObjectURL(blob);

        setPdf(fileURL)
        setSuccess(data.body.message)
        }
        if(data.status === 500) {
          setSuccess(data.body.message)
        }
      })
  }

  const handlePayPal = event => {
    setTimeout(() => {
      
    }, 1000);
    let my_token = localStorage.getItem("paypal_token");
    if(my_token ==="0")
    {
      setTimeout(() => {
        handlePayPal();
      }, 5000);
    }
    else{

      setTimeout(() => {
        
      }, 1000);

      fetch(`https://x5lper6q2g.execute-api.us-east-1.amazonaws.com/v1/createcustomerpurchase`, {
          method: "POST",
          headers: {
              'Content-Type': 'application/json',
              "Access-Control-Allow-Origin": "*",
              "Access-Control-Allow-Credentials": true,
              "x-api-key": "yn5R0SOtq9a574Oe9FQIQ8bKtndg8BRl2py67Bue",
              "token_id": my_token
          },
      }).then(response => response.json().then(data => ({ status: response.status, body: data })))
      .then(data => {
        if(data.status === 200) {
          var hex = (data.body.pdf)
          var byteArray = new Uint8Array(hex.length/2);
            for (var x = 0; x < byteArray.length; x++){
                byteArray[x] = parseInt(hex.substr(x*2,2), 16);
            }

            var blob = new Blob([byteArray], {type: "application/pdf"});
            var fileURL = URL.createObjectURL(blob);

        setPdf(fileURL)
        setSuccess(data.body.message)
        }
        if(data.status === 500) {
          setSuccess(data.body.message)
        }
      })
    }
  }

  const handlePDF = event => {
    if (event.preventDefault) event.preventDefault();
    window.open(pdf);

  }

  return (
    <div>
      <form onSubmit={handleSubmit} ref={form}>
        <div>
          <input
            type="hidden"
            data-recurly="first_name"
            placeholder="First Name"
            defaultValue="Test2"
          />
          <input
            type="hidden"
            data-recurly="last_name"
            placeholder="Last Name"
            defaultValue="User"
          />
        </div>
        <CardElement
          onBlur={handleBlur}
          onChange={handleChange}
          onFocus={handleFocus}
          onReady={handleReady}
          onSubmit={handleSubmit}
          style={{ fontSize }}
        />
        <div>
          <button>Add Payment Method & Pay $500</button>
        </div>
      </form>
        <div>
          <button id="paypal" onClick={handlePayPal}>Subscribe with PayPal & Pay $500</button>
        </div>  
        <div>
          <button onClick={handlePay}>Pay $500</button>
        </div>
        <div>
          {success ? <button onClick={handlePDF}>Download Invoice</button> : "" }
        </div>
        <div>
          <h4>{success}</h4>
        </div>
    </div>
  );
}
