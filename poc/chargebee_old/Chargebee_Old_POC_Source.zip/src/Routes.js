import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';

import UserDetails from './UserDetails';

class Routes extends Component {
    render() {
        return (
            <div>
                <BrowserRouter>
                    <Switch>
                        <Route path="/" exact={true} component={ UserDetails } />
                        {/* <Route path="/paypalintermediate" exact={true} component={ PaypalIntermediate } /> */}
                    </Switch>
                </BrowserRouter>
            </div>
        )
    }
}

export default Routes;