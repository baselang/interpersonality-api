self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "152368427732f5ed1bfd2c7189827ab4",
    "url": "/index.html"
  },
  {
    "revision": "54b4c2590f8506636042",
    "url": "/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "fc485b097414f146c9c8",
    "url": "/static/js/2.b7124ad9.chunk.js"
  },
  {
    "revision": "461eddee84a8080b6c87408ff51f1523",
    "url": "/static/js/2.b7124ad9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "54b4c2590f8506636042",
    "url": "/static/js/main.72f9854d.chunk.js"
  },
  {
    "revision": "bea57c6f3bd4bf0d65b2",
    "url": "/static/js/runtime-main.92d8d854.js"
  }
]);